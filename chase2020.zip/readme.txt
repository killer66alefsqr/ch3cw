To put your email go Go to chase/home/system/sand_email.php

Any help you need contact me via ticket